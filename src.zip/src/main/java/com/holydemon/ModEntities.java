package com.holydemon;

import com.holydemon.entity.AngelEntity;
import com.holydemon.entity.DemonEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;

public class ModEntities {
    public static final EntityType<AngelEntity> ANGEL = Registry.register(
            Registries.ENTITY_TYPE, new Identifier(HolyDemon.MOD_ID, "angel"),
            FabricEntityTypeBuilder.createMob()
                    .spawnGroup(SpawnGroup.CREATURE)
                    .entityFactory(AngelEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
                    .trackRangeBlocks(64)
                    .spawnRestriction(SpawnRestriction.Location.NO_RESTRICTIONS,
                            Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn)
                    .build());

    public static final EntityType<DemonEntity> DEMON = Registry.register(
            Registries.ENTITY_TYPE, new Identifier(HolyDemon.MOD_ID, "demon"),
            FabricEntityTypeBuilder.createMob()
                    .spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(DemonEntity::new)
                    .dimensions(EntityDimensions.fixed(0.7f, 2.0f))
                    .fireImmune()
                    .trackRangeBlocks(64)
                    .spawnRestriction(SpawnRestriction.Location.ON_GROUND,
                            Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, DemonEntity::canSpawnHere)
                    .build());

    public static void register() {}
}
