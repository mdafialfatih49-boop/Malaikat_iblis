package com.holydemon.client;

import com.holydemon.HolyDemon;
import com.holydemon.entity.AngelEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class AngelRenderer extends BipedEntityRenderer<AngelEntity, BipedEntityModel<AngelEntity>> {
    private static final Identifier TEXTURE = new Identifier(HolyDemon.MOD_ID, "textures/entity/angel.png");

    public AngelRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.4f);
    }

    @Override
    public Identifier getTexture(AngelEntity entity) { return TEXTURE; }
}
