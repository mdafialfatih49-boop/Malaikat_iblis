package com.holydemon.client;

import com.holydemon.HolyDemon;
import com.holydemon.entity.DemonEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class DemonRenderer extends BipedEntityRenderer<DemonEntity, BipedEntityModel<DemonEntity>> {
    private static final Identifier TEXTURE = new Identifier(HolyDemon.MOD_ID, "textures/entity/demon.png");

    public DemonRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.5f);
    }

    @Override
    public Identifier getTexture(DemonEntity entity) { return TEXTURE; }
}
