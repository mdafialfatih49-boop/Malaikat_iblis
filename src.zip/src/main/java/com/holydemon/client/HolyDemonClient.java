package com.holydemon.client;

import com.holydemon.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class HolyDemonClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.ANGEL, AngelRenderer::new);
        EntityRendererRegistry.register(ModEntities.DEMON, DemonRenderer::new);
    }
}
