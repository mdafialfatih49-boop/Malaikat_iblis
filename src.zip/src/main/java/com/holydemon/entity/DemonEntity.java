package com.holydemon.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;

/** Iblis: agresif, cepat, kebal api, serangan jarak dekat bisa membakar / memberi Wither. */
public class DemonEntity extends HostileEntity {

    public DemonEntity(EntityType<? extends DemonEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createDemonAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.36)   // zombie = 0.23
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 7.0)
                .add(EntityAttributes.GENERIC_ARMOR, 4.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.25, false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));

        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        this.targetSelector.add(3, new ActiveTargetGoal<>(this, VillagerEntity.class, false));
        this.targetSelector.add(3, new ActiveTargetGoal<>(this, AngelEntity.class, true));
    }

    @Override
    public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity living) {
            if (random.nextFloat() < 0.35f) target.setOnFireFor(6);                       // efek Fire Aspect
            if (random.nextFloat() < 0.20f)
                living.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 1), this); // Wither
        }
        return hit;
    }

    /** Efek api + asap di tubuh. */
    @Override
    public void tickMovement() {
        super.tickMovement();
        if (getWorld().isClient) {
            if (random.nextInt(2) == 0)
                getWorld().addParticle(ParticleTypes.FLAME, getParticleX(0.6), getRandomBodyY(), getParticleZ(0.6), 0, 0.02, 0);
            if (random.nextInt(2) == 0)
                getWorld().addParticle(ParticleTypes.LARGE_SMOKE, getParticleX(0.6), getRandomBodyY(), getParticleZ(0.6), 0, 0.03, 0);
        }
    }

    public static boolean canSpawnHere(EntityType<DemonEntity> type, ServerWorldAccess world, SpawnReason reason,
                                       BlockPos pos, Random random) {
        if (world.getDifficulty() == Difficulty.PEACEFUL) return false;
        boolean okLight = world.getDimension().ultrawarm() || HostileEntity.isSpawnDark(world, pos, random);
        return okLight && MobEntity.canMobSpawn(type, world, reason, pos, random);
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_WITHER_SKELETON_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENTITY_WITHER_SKELETON_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_WITHER_SKELETON_DEATH; }
}
