package com.holydemon.entity;

import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityGroup;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Malaikat: terbang, netral ke player (kecuali diserang), memburu Iblis & Undead dengan panah suci. */
public class AngelEntity extends PathAwareEntity implements net.minecraft.entity.mob.RangedAttackMob {

    public AngelEntity(EntityType<? extends AngelEntity> type, World world) {
        super(type, world);
        this.moveControl = new FlightMoveControl(this, 20, true);
        this.setNoGravity(true);
    }

    public static DefaultAttributeContainer.Builder createAngelAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.6)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0);
    }

    @Override
    protected void initGoals() {
        // AI aksi
        this.goalSelector.add(1, new ProjectileAttackGoal(this, 1.0, 30, 20.0f));
        this.goalSelector.add(5, new FlyGoal(this, 1.0));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));

        // AI target: player hanya diserang kalau menyerang duluan (RevengeGoal)
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, DemonEntity.class, true));
        this.targetSelector.add(3, new ActiveTargetGoal<>(this, MobEntity.class, 10, true, false,
                e -> e.getGroup() == EntityGroup.UNDEAD));
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        BirdNavigation nav = new BirdNavigation(this, world);
        nav.setCanPathThroughDoors(false);
        nav.setCanSwim(true);
        nav.setCanEnterOpenDoors(true);
        return nav;
    }

    /** Serangan: panah suci (bercahaya). */
    @Override
    public void attack(LivingEntity target, float pullProgress) {
        ArrowEntity arrow = new ArrowEntity(getWorld(), this);
        arrow.setDamage(4.0);
        arrow.setCritical(true);
        arrow.setNoGravity(true);
        arrow.setGlowing(true);
        double dx = target.getX() - getX();
        double dy = target.getBodyY(0.5) - arrow.getY();
        double dz = target.getZ() - getZ();
        arrow.setVelocity(dx, dy, dz, 1.8f, 2.0f);
        playSound(SoundEvents.ENTITY_SKELETON_SHOOT, 1.0f, 1.4f);
        getWorld().spawnEntity(arrow);
    }

    /** Efek holy glow + halo di atas kepala. */
    @Override
    public void tickMovement() {
        super.tickMovement();
        if (getWorld().isClient) {
            if (random.nextInt(2) == 0) {
                getWorld().addParticle(ParticleTypes.END_ROD, getParticleX(0.6), getRandomBodyY(), getParticleZ(0.6), 0, 0.02, 0);
            }
            if (random.nextInt(5) == 0) {
                getWorld().addParticle(ParticleTypes.GLOW, getParticleX(0.8), getRandomBodyY(), getParticleZ(0.8), 0, 0.01, 0);
            }
            double a = age * 0.3;
            getWorld().addParticle(ParticleTypes.END_ROD, getX() + Math.cos(a) * 0.3, getY() + 2.15, getZ() + Math.sin(a) * 0.3, 0, 0, 0);
        }
    }

    @Override public boolean handleFallDamage(float d, float m, DamageSource s) { return false; }
    @Override protected void fall(double h, boolean onGround, BlockState state, BlockPos pos) {}

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_ALLAY_AMBIENT_WITHOUT_ITEM; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENTITY_ALLAY_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_ALLAY_DEATH; }
}
