package com.holydemon;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item HOLY_FEATHER = reg("holy_feather", new Item(new FabricItemSettings()));
    public static final Item DEMON_HORN = reg("demon_horn", new Item(new FabricItemSettings()));
    public static final Item ANGEL_SPAWN_EGG = reg("angel_spawn_egg",
            new SpawnEggItem(ModEntities.ANGEL, 0xFFF4C2, 0xFFD54F, new FabricItemSettings()));
    public static final Item DEMON_SPAWN_EGG = reg("demon_spawn_egg",
            new SpawnEggItem(ModEntities.DEMON, 0x8B0000, 0x1A1A1A, new FabricItemSettings()));

    private static Item reg(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(HolyDemon.MOD_ID, name), item);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(e -> {
            e.add(HOLY_FEATHER);
            e.add(DEMON_HORN);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(e -> {
            e.add(ANGEL_SPAWN_EGG);
            e.add(DEMON_SPAWN_EGG);
        });
    }
}
