package com.holydemon;

import com.holydemon.entity.AngelEntity;
import com.holydemon.entity.DemonEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.SpawnGroup;

public class HolyDemon implements ModInitializer {
    public static final String MOD_ID = "holydemon";

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();

        FabricDefaultAttributeRegistry.register(ModEntities.ANGEL, AngelEntity.createAngelAttributes());
        FabricDefaultAttributeRegistry.register(ModEntities.DEMON, DemonEntity.createDemonAttributes());

        // Spawn alami: Malaikat di Overworld (jarang), Iblis di Nether (sering) + Overworld malam (jarang)
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, ModEntities.ANGEL, 3, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.foundInTheNether(), SpawnGroup.MONSTER, ModEntities.DEMON, 15, 1, 2);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ModEntities.DEMON, 3, 1, 1);
    }
}
